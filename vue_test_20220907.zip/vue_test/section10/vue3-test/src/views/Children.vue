<template>
  <div>Children (子)</div>
  <Grand-Children />
</template>

<script>
import GrandChildren from '@/components/GrandChildren'

export default {
  components:{
    GrandChildren
  }
}
</script>

<style>

</style>