<template>
  <div>
    GrandChildren(孫)
  </div>
  <div>{{ userName }}</div>
</template>

<script>
export default {
  data(){},
  inject: ['userName']
}
</script>

<style>

</style>