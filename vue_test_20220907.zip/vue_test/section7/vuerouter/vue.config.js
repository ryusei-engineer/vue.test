module.exports = {
 publicPath: ''
}